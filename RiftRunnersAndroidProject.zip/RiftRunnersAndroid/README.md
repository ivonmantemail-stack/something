# Rift Runners — Android project

This is a self-contained Android Studio project. It embeds the current prototype gameplay as local HTML/JavaScript assets, so it does not depend on the hosted site being public to launch.

## Important status
- **Included:** Android WebView wrapper, offline prototype game assets, Gradle configuration, and GitHub Actions workflow.
- **Not included:** compiled APK or AAB. This ZIP is source code, not an installable app.
- **Online multiplayer:** not implemented; the rival characters are local simulated bots.
- **Google Play release:** the generated `bundleRelease` AAB is unsigned by default. A release signing key and Play Console setup are still required.

## Build from a PC
1. Install Android Studio and open this folder.
2. Let Gradle sync.
3. For a quick test: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. For Play Store upload: Build > Generate Signed Bundle / APK > Android App Bundle. Create and securely back up a signing key.

## Build with only your phone (cloud build)
The included GitHub Actions workflow can build the APK and AAB on GitHub's cloud runners:
1. Create a repository on https://github.com/new using your browser.
2. Upload the extracted contents of this project to the repository (not just the ZIP file). Ensure `.github/workflows/android.yml` is included.
3. Open the repository's **Actions** tab, select **Build Rift Runners Android**, and tap **Run workflow**.
4. Wait for the workflow to finish, open the successful run, then download the `rift-runners-android-builds` artifact ZIP. It contains a debug APK and an unsigned release AAB.
5. The debug APK is for direct testing. For Google Play, configure release signing and rebuild a signed AAB. Do not share your private signing key or passwords.

On Android, you may need to allow installation from the browser/file manager used to open the debug APK. Only install APKs you trust.

## Google Play
New personal developer accounts created after 13 November 2023 generally must run a closed test with at least 12 opted-in testers for 14 consecutive days before applying for production access. Check current requirements in Play Console Help.
